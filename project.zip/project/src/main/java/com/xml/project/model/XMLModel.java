package com.xml.project.model;

public class XMLModel {

}
