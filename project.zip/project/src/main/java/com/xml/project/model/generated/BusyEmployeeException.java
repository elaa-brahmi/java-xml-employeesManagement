package com.xml.project.model.generated;


public class BusyEmployeeException extends RuntimeException {
    public BusyEmployeeException(String message) {
        super(message);
    }
}