package com.xml.project.model.generated;

public class UnfoundIdException extends RuntimeException {
    public UnfoundIdException(String message) {
        super(message);
    }
}
