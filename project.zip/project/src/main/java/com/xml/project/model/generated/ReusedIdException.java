package com.xml.project.model.generated;

public class ReusedIdException extends RuntimeException {
    public ReusedIdException(String message) {
        super(message);
    }
}
