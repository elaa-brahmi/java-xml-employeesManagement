package com.xml.project.model.generated;

public class UnderMaintenanceException extends RuntimeException {
    public UnderMaintenanceException(String message) {
        super(message);
    }
}