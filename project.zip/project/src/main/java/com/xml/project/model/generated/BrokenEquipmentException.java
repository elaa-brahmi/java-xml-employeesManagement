package com.xml.project.model.generated;

public class BrokenEquipmentException extends RuntimeException{
    public BrokenEquipmentException(String message) {
        super(message);
    }
}
